# Tenant FAQ (fictional document)

## How much notice do I have to give before leaving?
For a furnished flat, one month. Send your notice by registered letter, or hand it over against a signature. The notice period starts when the landlord receives the letter.

## When do I get my deposit back?
Within one month after you return the keys if the check-out inspection matches the check-in inspection, and within two months otherwise.

## Who pays for repairs?
Small repairs and day-to-day upkeep are paid by the tenant. Major repairs, such as replacing the boiler, are paid by the landlord. Report any breakdown as soon as possible.

## Can I keep a cat or a dog?
Yes, pets are allowed as long as they cause no damage and do not disturb the neighbours.

## Where can I park my bike?
In the bike room on the ground floor, which opens with your badge.
